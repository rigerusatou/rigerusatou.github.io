Minecraft Plugin Update Canary v0.1
===================================

Purpose
-------
Compare a currently working Minecraft plugin with a candidate JAR in sibling canary copies of the same server inputs before you deploy the update.

Requirements
------------
- Java 21 to run the CLI.
- Docker installed and running for the default isolated canary mode.
- A Paper/Spigot server directory that already starts successfully.
- The candidate plugin JAR must be outside the production server directory.

Quick start
-----------
java -jar minecraft-update-canary.jar test \
  --server /path/to/server \
  --plugin ExamplePlugin \
  --candidate /path/to/ExamplePlugin-2.0.jar

Canary server Java selection defaults to `--runtime-java auto`: Java 21 first, then Java 25 only when startup evidence explicitly shows a class-version mismatch.

If more than one server JAR exists, select it explicitly:
  --server-jar paper-1.21.11.jar

If more than one installed JAR declares the same logical plugin name, select it explicitly:
  --before-jar ExamplePlugin-1.0.jar

Docker and --unsafe-local
-------------------------
Docker is the default. Canary containers run with outbound networking disabled (`--network none`) and bounded CPU/memory.

`--unsafe-local` explicitly runs the copied canary workspace with the local Java process. It does NOT provide Docker network isolation. The tool never falls back to local execution silently.

Verdicts and exit codes
-----------------------
0  UPDATE SAFE       No regression was detected by configured checks.
1  REVIEW            A change needs human review before deployment.
2  BLOCK             A clear regression/incompatibility was detected.
3  INCOMPLETE TEST   The canary could not gather sufficient evidence; do not treat this as safe.

`UPDATE SAFE` means no regression was detected by configured checks, not a universal safety guarantee.

Evidence and reports
--------------------
Each invocation writes a run under `canary-runs/<run-id>/` including `report.json`, `summary.txt`, sibling `baseline/` and `candidate/` workspaces, normalized evidence, and preserved pre-update plugin bytes in the Candidate evidence area.

The production server directory is read-only input. The tool does not intentionally write to it.

v0.1 checks
-----------
- target plugin load/enabled regression
- hard/soft dependency changes
- YAML/JSON structural config regressions (without reporting scalar secret values)
- command registry changes
- permission registry changes
- new severe log fingerprints
- file migration zero-byte corruption
- external-service/network-isolation regressions

Release verification
--------------------
Unit verification:
  mvn clean verify

Docker-tagged release gate:
  mvn verify -Dgroups=docker

The Docker gate requires Docker to be installed and running, plus `CANARY_TEST_SERVER` pointing to a clean, startable Paper/Spigot test server. If that directory contains multiple root server JARs, set `CANARY_TEST_SERVER_JAR` to the server JAR filename.

Automated GitHub release gate
-----------------------------
`.github/workflows/release-gate.yml` runs `mvn clean verify` on normal pull requests / main-branch pushes. A manual workflow dispatch or a `v*` tag prepares a clean Paper 1.21.11 server, runs the full Docker-tagged fixture suite through `scripts/package-release.sh`, and uploads the Marketplace ZIP as a workflow artifact.

The Paper bootstrap helper is `scripts/prepare-paper-test-server.sh`. It deliberately pins Paper 1.21.11 for the v0.1 release fixture and requires `PAPERMC_USER_AGENT` to contain a contact URL or email, matching PaperMC download-service requirements.


GITHUB PUBLISH HELPER
=====================
If the repository does not exist yet, the included helper can create a private repository, push this source tree, and dispatch the Release Gate workflow.

Windows PowerShell:
  powershell -ExecutionPolicy Bypass -File scripts\publish-github.ps1

macOS/Linux:
  scripts/publish-github.sh

Requirements: Git, GitHub CLI (`gh`), and an authenticated `gh auth login` session.
