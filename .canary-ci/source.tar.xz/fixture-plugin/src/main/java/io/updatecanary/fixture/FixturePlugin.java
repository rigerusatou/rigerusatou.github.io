package io.updatecanary.fixture;
import java.nio.file.*;import org.bukkit.plugin.java.JavaPlugin;
public final class FixturePlugin extends JavaPlugin {
 public enum Mode { SAFE, NEW_SEVERE_WARNING, THROW_ON_ENABLE, CONFIG_TYPE_FAILURE, MIGRATION_ZERO_BYTE }
 @Override public void onEnable(){saveDefaultConfig();Mode mode=Mode.valueOf(getConfig().getString("mode","SAFE").trim().toUpperCase());switch(mode){case SAFE->{}case NEW_SEVERE_WARNING->getLogger().severe("CANARY_FIXTURE_NEW_SEVERE_WARNING");case THROW_ON_ENABLE->throw new IllegalStateException("CANARY_FIXTURE_THROW_ON_ENABLE");case CONFIG_TYPE_FAILURE->{if(!getConfig().isInt("threshold"))throw new IllegalStateException("CANARY_FIXTURE_CONFIG_TYPE_FAILURE");}case MIGRATION_ZERO_BYTE->{try{Files.createDirectories(getDataFolder().toPath());Files.write(getDataFolder().toPath().resolve("data.yml"),new byte[0]);}catch(Exception e){throw new IllegalStateException("CANARY_FIXTURE_MIGRATION_ZERO_BYTE",e);}}}}
}
